import random 
winCount = 0 
tieCount = 0 
loseCount = 0 
computerChoice = ["Rock", "Paper", "Scissors"]
def play(): 
   global winCount, tieCount, loseCount 
   win = False
   lose = False
   tie = False
   gameEnd = False
   computer = random.choice(computerChoice)
   player = input("pick choice of rock, paper, scissors >")
   player=player.lower()
   if ((computer == "Rock" and player == "rock") or
       (computer == "Paper" and player == "paper")):
     print("tie")
     tie = True
     tieCount+=1
     gameEnd=True 
   if computer == "Rock" and player == "scissors":
     print("You lose")
     lose = True 
     loseCount+=1
     gameEnd =True
   if computer == "Scissors" and player=="scissors":
     print("tie")
     tie = True 
     tieCount+=1
     gameEnd =True
   if computer == "Paper" and player == "scissors":
     print("You win")
     win = True 
     winCount+=1
     gameEnd = True
   if computer == "Paper" and player == "rock":
     print("You lose")
     lose = True 
     loseCount+=1
     gameEnd = True
   if computer == "Scissors" and player == "rock":
     print("You win")
     win = True 
     winCount+=1
     gameEnd = True
   if computer == "Scissors" and player == "paper":
     print("You lose")
     lose = True 
     loseCount+=1
     gameEnd = True
   if computer == "Rock" and player == "paper":
     print("You win")
     win = True 
     winCount+=1
     gameEnd = True
   







play()
